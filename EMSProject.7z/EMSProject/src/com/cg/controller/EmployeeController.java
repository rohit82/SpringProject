package com.cg.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.Employee;
import com.cg.entities.User;
import com.cg.exception.EmployeeException;

import com.cg.service.EmployeeService;



@Controller
public class EmployeeController 
{
	@Autowired
	private EmployeeService employeeService;
	
	public EmployeeController() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String myLog( User user,HttpSession session)
	{
	
		
		return "login";
		
	}
	
	@RequestMapping("authenticate")
	public String myLogin(@RequestParam("userName")String name , @RequestParam("password")String pass,
			User user,HttpSession session) throws EmployeeException
	{
		System.out.println("In controller");
		System.out.println("UserName:" +name +"pas" + pass );
		String retPage ;
		String role = employeeService.getRole(name,pass);
		System.out.println(role);
	
		if(role.equals("employee"))
		{
			//session.setAttribute("userId", user.getUserId());
			retPage = "employee";
			System.out.println(retPage);
		}
		
		
		else if(role.equals("admin"))
		{
			retPage = "admin";
			System.out.println(retPage);
		}
		else
		{
			retPage = "login"; 
		}
		
		return retPage;
	}
	
	@RequestMapping("addEmployee")
	public String getAddEmployeePage()
	{
		return "addEmployee";
		
	}
	
	@RequestMapping(value="addEmployeeDetails")
	public String employeeAdd(@ModelAttribute("data") Employee employee ) throws EmployeeException
	{
		System.out.println("Here");
		employeeService.addEmployeeDetails(employee);
			
		return "added";
	}
	
	
}
