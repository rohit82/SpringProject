package com.cg.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.User;
import com.cg.service.EmployeeService;



@Controller
public class EmployeeController 
{
	@Autowired
	private EmployeeService employeeService;
	
	public EmployeeController() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String myLog( User user,HttpSession session)
	{
	
		
		return "login";
		
	}
	
	/*@RequestMapping(value="Login.do",method=RequestMethod.POST)
	public String myLogin(@RequestParam("name") String name , @RequestParam("pass") 
		String pass, User user,HttpSession session)
	{
		String retPage = null;
	//	String role = employeeService
	
		if(role.equals("User"))
		{
			session.setAttribute("userId", user.getUserId());
			retPage = "userHome";
		}
		
		else if(role.equals("Employee"))
		{
			retPage = "userHome";
		}
		
		else if(role.equals("Admin"))
		{
			retPage = "index";
		}
		else
		{
			retPage = "error"; 
		}
		
		return retPage;
	}*/
	
}
