package com.cg.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.entities.Employee;
import com.cg.entities.User;
import com.cg.exception.EmployeeException;



public interface EmployeeDao {
	
	void addEmployeeDetails(Employee emp) throws EmployeeException;
	int addLoginDetails(User user) throws  EmployeeException;
	List<Employee> showAll() throws EmployeeException, SQLException;
	int	isValid(String userName,String userPassword)throws EmployeeException;
	
	Employee searchEmployeeOnId(String EmpId)throws EmployeeException;
	List<Employee> searchEmployeeOnFirstName(String firstName) throws EmployeeException;
	List<Employee> searchEmployeeOnLastName(String lastName) throws EmployeeException;
	
	List<Employee> searchEmployeeOnDepartment(String empDept1, String empDept2, String empDept3, String empDept4, String empDept5, String empDept6) throws EmployeeException;
	List<Employee> searchEmployeeOnGrade(String grade1, String grade2, String grade3, String grade4, String grade5, String grade6, String grade7) throws EmployeeException;
	List<Employee> searchEmployeeOnMaritalStatus(String status1, String status2, String status3, String status4, String status5) throws EmployeeException;
	void updateEmployee(Employee emp)throws EmployeeException;
	
	String getRole(String userName, String userPassword) throws EmployeeException;
	
	

	
	
}
