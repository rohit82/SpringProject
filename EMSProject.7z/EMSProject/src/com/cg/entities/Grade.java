package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Grade_Master")
public class Grade {

	
	@NotEmpty(message="Grade Code cannot be empty")
	@Column(name="Grade_Code" ,nullable=false)
	private String gradeCode;
	
	@NotEmpty(message="Grade Description cannot be empty")
	@Column(name="Description" ,nullable=false)
	private String gradeDescription;
	
	@NotEmpty(message="Min Salary cannot be empty")
	@Column(name="Min_Salary" ,nullable=false)
	private int gradeMinSalary;
	
	@NotEmpty(message="Max Salary cannot be empty")
	@Column(name="Max_Salary" ,nullable=false)
	private int gradeMaxsalary;
	
	
	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Grade(String gradeCode, String gradeDescription,
			int gradeMinSalary, int gradeMaxsalary) {
		super();
		this.gradeCode = gradeCode;
		this.gradeDescription = gradeDescription;
		this.gradeMinSalary = gradeMinSalary;
		this.gradeMaxsalary = gradeMaxsalary;
	}


	public String getGradeCode() {
		return gradeCode;
	}


	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}


	public String getGradeDescription() {
		return gradeDescription;
	}


	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}


	public int getGradeMinSalary() {
		return gradeMinSalary;
	}


	public void setGradeMinSalary(int gradeMinSalary) {
		this.gradeMinSalary = gradeMinSalary;
	}


	public int getGradeMaxsalary() {
		return gradeMaxsalary;
	}


	public void setGradeMaxsalary(int gradeMaxsalary) {
		this.gradeMaxsalary = gradeMaxsalary;
	}


	@Override
	public String toString() {
		return "Grade [gradeCode=" + gradeCode + ", gradeDescription="
				+ gradeDescription + ", gradeMinSalary=" + gradeMinSalary
				+ ", gradeMaxsalary=" + gradeMaxsalary + "]";
	}
	
	
	
	
}
