package com.cg.entities;





import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;




@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	@Column(name="Emp_ID")
	private String empId;
	
	
	@Column(name="Emp_First_Name" , nullable=false)
	private String empFname;
	
	//@NotEmpty(message="Name cannot be empty")
	@Column(name="Emp_Last_Name" , nullable=false)
	private String empLname;
	
	//@NotEmpty(message="Name cannot be empty")
	@Column(name="Emp_Date_of_Birth" , nullable=false)
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date empDateOfBirth;
	
	//@NotEmpty(message="Name cannot be empty")
	@Column(name="Emp_Date_of_Joining" , nullable=false)
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date empDateOfJoining;
	
	//@NotEmpty(message="Emp_Dept_ID cannot be empty")
	@Column(name="Emp_Dept_ID" , nullable=false)
	private int empDeptId;
	
	//@NotEmpty(message="Emp_Grade cannot be empty")
	@Column(name="Emp_Grade" , nullable=false)
	private String empGrade;
	
	//@NotEmpty(message="Emp_Designation cannot be empty")
	@Column(name="Emp_Designation" , nullable=false)
	private String empDesignation;
	
	//@NotEmpty(message="Emp_Basic cannot be empty")
	@Column(name="Emp_Basic" , nullable=false)
	private int empBasic;
	
	//@NotEmpty(message="Emp_Gender cannot be empty")
	@Column(name="Emp_Gender" , nullable=false)
	private String empGender;
	
	//@NotEmpty(message="Emp_Marital_Status cannot be empty")
	@Column(name="Emp_Marital_Status" , nullable=false)
	private String empMaritalStatus;
	
	//@NotEmpty(message="Emp_Home_Address cannot be empty")
	@Column(name="Emp_Home_Address" , nullable=false)
	private String empHomeAddress;
	
	//@NotEmpty(message="Emp_Contact_num cannot be empty")
	@Column(name="Emp_Contact_num" , nullable=false)
	private String empContactNo;
	

	public Employee() {
		super();
	}




	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public String getEmpFname() {
		return empFname;
	}


	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}


	public String getEmpLname() {
		return empLname;
	}


	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}


	public Date getEmpDateOfBirth() {
		return empDateOfBirth;
	}


	public void setEmpDateOfBirth(Date empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}


	public Date getEmpDateOfJoining() {
		return empDateOfJoining;
	}


	public void setEmpDateOfJoining(Date empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}


	public int getEmpDeptId() {
		return empDeptId;
	}


	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}


	public String getEmpGrade() {
		return empGrade;
	}


	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}


	public String getEmpDesignation() {
		return empDesignation;
	}


	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}


	public int getEmpBasic() {
		return empBasic;
	}


	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}


	public String getEmpGender() {
		return empGender;
	}


	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}


	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}


	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}


	public String getEmpHomeAddress() {
		return empHomeAddress;
	}


	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}


	public String getEmpContactNo() {
		return empContactNo;
	}


	public void setEmpContactNo(String empContactNo) {
		this.empContactNo = empContactNo;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFname=" + empFname
				+ ", empLname=" + empLname + ", empDateOfBirth="
				+ empDateOfBirth + ", empDateOfJoining=" + empDateOfJoining
				+ ", empDeptId=" + empDeptId + ", empGrade=" + empGrade
				+ ", empDesignation=" + empDesignation + ", empBasic="
				+ empBasic + ", empGender=" + empGender + ", empMaritalStatus="
				+ empMaritalStatus + ", empHomeAddress=" + empHomeAddress
				+ ", empContactNo=" + empContactNo+"]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empId == null) ? 0 : empId.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		
		if (empId == null) {
			if (other.empId != null)
				return false;
		} else if (!empId.equals(other.empId))
			return false;
		return true;
	}
	
	
	
	
	

}
