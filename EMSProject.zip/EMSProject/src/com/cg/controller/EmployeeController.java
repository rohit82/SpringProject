package com.cg.controller;

import java.util.ArrayList;
import java.util.List;






import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.Employee;
import com.cg.entities.User;
import com.cg.exception.EmployeeException;

import com.cg.service.EmployeeService;



@Controller
public class EmployeeController 
{
	@Autowired
	private EmployeeService employeeService;
	
	public EmployeeController() {
		
		
	}

	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	@RequestMapping("login")
	public String myLog( User user,HttpSession session)
	{
	
		return "login";
		
	}
	
	@RequestMapping("authenticate")
	public String myLogin(@RequestParam("userName")String name , @RequestParam("password")String pass,
			User user,HttpSession session) throws EmployeeException
	{
		System.out.println("In controller");
		System.out.println("UserName:" +name +"pas" + pass );
		String retPage ;
		String role = employeeService.getRole(name,pass);
		System.out.println(role);
	
		if(role.equals("employee"))
		{
			
			retPage = "employee";
			System.out.println(retPage);
		}
		
		
		else if(role.equals("admin"))
		{
			retPage = "admin";
			System.out.println(retPage);
		}
		else
		{
			retPage = "login"; 
		}
		
		return retPage;
	}
	
	@RequestMapping("addEmployee")
	public String getAddEmployeePage(Model model)
	{
		
		List<String> maritalstatus = new ArrayList<>();
		maritalstatus.add("Married");
		maritalstatus.add("Single");
		maritalstatus.add("Seperated");
		maritalstatus.add("Divorce");
		maritalstatus.add("Widowed");
		
		List<String> gender = new ArrayList<>();
		gender.add("Male");
		gender.add("Female");
		
		List<String> grade = new ArrayList<>();
		grade.add("M1");
		grade.add("M2");
		grade.add("M3");
		grade.add("M4");
		grade.add("M5");
		grade.add("M6");
		grade.add("M7");
		
		
 		model.addAttribute("employee", new Employee());
 		
 		model.addAttribute("user", new User());
		
 		model.addAttribute("maritalstatus", maritalstatus);
		
 		model.addAttribute("gender", gender);
 		
 		model.addAttribute("grade", grade);
		
 		return "addEmployee";
		
	}
	
	@RequestMapping(value="addEmployeeDetails")
	public ModelAndView employeeAdd(@ModelAttribute("employee") @Valid Employee employee ,@ModelAttribute("user")
	@Valid User user,  BindingResult result, Model model ) throws EmployeeException
	{

		if(result.hasErrors() == true)
		{
			List<String> maritalstatus = new ArrayList<>();
			maritalstatus.add("Married");
			maritalstatus.add("Single");
			maritalstatus.add("Seperated");
			maritalstatus.add("Divorce");
			maritalstatus.add("Widowed");
			
			List<String> gender = new ArrayList<>();
			gender.add("Male");
			gender.add("Female");
			
			List<String> grade = new ArrayList<>();
			grade.add("M1");
			grade.add("M2");
			grade.add("M3");
			grade.add("M4");
			grade.add("M5");
			grade.add("M6");
			grade.add("M7");
			
	 		model.addAttribute("employee", employee);
	 		
	 		model.addAttribute("user",  user);
			
	 		model.addAttribute("maritalstatus", maritalstatus);
			
	 		model.addAttribute("gender", gender);
	 		
	 		model.addAttribute("grade", grade);
	 		
			/*return new ModelAndView("addEmployee");*/
		}
		
		
		try
		{
			System.out.println("Added");
			employeeService.addEmployeeDetails(employee);
			employeeService.addLoginDetails(user);
			model.addAttribute("message", "Employee Added Successfully");
			return new ModelAndView("added");
		}
		catch(Exception e)
		{
			
			model.addAttribute("errMsg", "Could not add employee" + e.getMessage());
			return new ModelAndView("error");
		}
		
	
			
		
	}
	
	
	
	@RequestMapping("searchEmployeeOnId")
	public String getSearchEmployeeOnId(Model model)
	{
		return "searchEmployeeOnId";
		
	}
	
	@RequestMapping(value="showEmployeebyId",method=RequestMethod.POST)
	public ModelAndView searchData(@ModelAttribute("data") Employee employee)

	{
		String empid = employee.getEmpId();
		 Employee searchData = null;
		try {
			searchData = employeeService.searchEmployeeOnId(empid);
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
		return new ModelAndView("employeeList1", "emp", searchData);
		
	}
	
	@RequestMapping(value="searchEmployeeOnFirstName")
	public String getEmployeebyFirstName(Model model)
	{
		return "searchEmployeeOnFirstName";
	}
	
	
	@RequestMapping(value="showEmployeeOnFirstName",method=RequestMethod.POST)
	public ModelAndView Data(@ModelAttribute("data") Employee employee)
	{
		String firstName = employee.getEmpFname();
		List<Employee> Data = null;
		try {
			Data = employeeService.searchEmployeeOnFirstName(firstName);
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
		return new ModelAndView("employeeFirstName" ,"status" , Data);
	}
	
	
	@RequestMapping(value="searchEmployeeOnLastName")
	public String getEmployeebyLastName(Model model)
	{
		return "searchEmployeeOnLastName";
	}
	
	
	@RequestMapping(value="showEmployeeOnLastName",method=RequestMethod.POST)
	public ModelAndView ListData(@ModelAttribute("data") Employee employee)
	{
		String lastName = employee.getEmpLname();
		List<Employee> Data = null;
		try {
			Data = employeeService.searchEmployeeOnLastName(lastName);
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
		return new ModelAndView("employeeFirstName" ,"status" , Data);
	}
	
	@RequestMapping("viewAllEmp")
	public String getAllEmployees(Model model)
	{
		List<Employee> eList = new ArrayList<Employee>();
		try
		{
			eList = employeeService.showAll();
			System.out.println(eList);
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg", "Could Not Retrieve the list " + e.getMessage()) ;
			return "error";
		}
		model.addAttribute("status", eList);
		return "viewAllEmp";
	}
	
	/************************************************************
	 * Searching employee based on employee Marital Status
	 *************************************************************/
	
	@RequestMapping("searchEmployeeOnMaritalStatus")
	public String getSearchEmployeeByMaritalStatus(Model model)
	{
		
		return "searchEmployeeOnMaritalStatus";
	}
	
	@RequestMapping("processSearchEmployeeOnMaritalStatus")
	public ModelAndView processSearchEmployeeByMaritalStatus(@RequestParam("empMaritalStatus") String empMaritalStatus)
	{
		List<Employee> employees=null;
		
		try 
		{
			System.out.println("In try");
			employees=employeeService.searchEmployeeOnMaritalStatus(empMaritalStatus);
					
			return new ModelAndView("employeeMaritalStatus","employees",employees);
		} 
		catch (Exception e) 
		{
			System.out.println("in catch");
			return new ModelAndView("error","errmsg","Could not get employee. Reason :"+e.getMessage());
		}
		
	
	}
	
}
