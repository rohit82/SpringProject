package com.cg.empSystem.dao;

import java.util.List;
import java.util.Random;
import java.security.SecureRandom;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

@Repository("empDao")
public class EmployeeDaoImpl implements EmployeeDao{
	
	@PersistenceContext
	private EntityManager manager;
	
	//Declaring the variable to have the random password
	private static final Random RANDOM = new SecureRandom();
	public static final int PASSWORD_LENGTH = 8;
	
	//Start Of Add Employee
	
	//Adding the Employee Data To database
	@Override
	public Employee addEmployee(Employee emp) throws EmployeeException {
		try {
			String deptName = emp.getDeptName();
			Department dept = this.getDeptId(deptName);
			dept.setDeptId(dept.getDeptId());
			emp.setEmpDeptId(dept.getDeptId());
			
			String userId = this.addUserMaster(emp);   //call addusermaster method 
			emp.setEmpId(userId);
			manager.persist(emp);
			manager.flush();
		} catch (RollbackException rl) {
			throw new EmployeeException("Employee duplicated",rl);
		}
		return emp;
	}
	
	
	//Getting the department name to populate to form 
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDeptname() throws EmployeeException {
		List<String> deptNmList;
		try {
			Query qry = manager.createQuery("select d.deptName from department as d");
			deptNmList = qry.getResultList();
		} catch (Exception e) {
			throw new EmployeeException("Improper query fabrication",e);
		}
		return deptNmList;
	}
	
	//Getting the department id on basis of department's name
	public Department getDeptId(String deptName) throws EmployeeException {
		Department dept = null;
		try {
			TypedQuery<Department> qry = manager.createNamedQuery("getdeptId",Department.class);
			qry.setParameter("dName", deptName);
			dept = qry.getSingleResult();
		} catch (Exception e) {
			throw new EmployeeException("Improper query fabrication",e);
		}
		return dept;
	}
	
	//Used to have generate password
	public String generateRandomPassword(){
	      String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789+@";

	      String pw = "";
	      for (int i=0; i<PASSWORD_LENGTH; i++)
	      {
	          int index = (int)(RANDOM.nextDouble()*letters.length());
	          pw += letters.substring(index, index+1);
	      }
	      return pw;
	  }
	
	//used to have generate userName
	public String generaeteUserName(Employee emp){
		String userName = null;
		System.out.println(emp.getEmpFname());
		
		String fName = emp.getEmpFname();
		
		if(fName.length()>=6){
			System.out.println(fName.substring(0, 6));
			int a = (int) (Math.random()*100);
			userName = fName.substring(0,6)+"."+a+"@capge.com";
			System.out.println(userName);
		}else{
			int a = (int) (Math.random()*100);
			userName = fName+"."+a+"@capge.com";
			System.out.println(userName);
		}
		return userName;
	}
	
	//Adding the user's to database 
	public String addUserMaster(Employee emp){
		String userPwd = this.generateRandomPassword();
		String userNm = this.generaeteUserName(emp);
		UserMaster usermaster = new UserMaster();
		usermaster.setUserName(userNm);
		usermaster.setUserPassword(userPwd);
		usermaster.setUserType("Employee");
		manager.persist(usermaster);
		String userId=usermaster.getUserId();
		System.out.println(userId);
		return userId;
	}//End the user's data to database 
	//End of Add 
	
	//Start Of Delete data from database
	
	//Delete data from employee details
	@Override
	public boolean removeEmployeeDetails(String employeeId) throws EmployeeException {
	Employee employee = null;
	System.out.println(employeeId);
	String id=employeeId;
	try {

		employee = manager.find(Employee.class, employeeId);
		manager.remove(employee);
		this.removeUserDetails(id);
		return true;
	} catch (RollbackException e) {
		throw new EmployeeException("Record not deleted", e);
	}
		
	}//End 

	//Delete data of user details from database
	@Override
	public boolean removeUserDetails(String userId) throws EmployeeException {
		Employee employee = null;
		UserMaster user = null;
		System.out.println(userId);
		
		
		try {
			user = manager.find(UserMaster.class, userId);
			manager.remove(user);
			return true;
		
		} catch (RollbackException e) {
			throw new EmployeeException("Record not deleted", e);
		}
			
	}//end
	
	//End of data's removal  from database
	
	//Start Of Show All
	@Override
	public List<Employee> showAllEmployee() throws EmployeeException {
		Query qry= manager.createNamedQuery("qryAllEmps", Employee.class);
		List<Employee> e=qry.getResultList();
		System.out.println(e);
		return e;
	}//End of Show All
	
	//Start of search employee on first name 
	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)throws EmployeeException {
		TypedQuery<Employee> qry = manager.createNamedQuery("qrySearchEmployeeByFirstName", Employee.class);
		qry.setParameter("firstName", firstName);
		return qry.getResultList();
	}//end of search employee on first name

	//search of employee on last name
	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)throws EmployeeException {
		TypedQuery<Employee> qry = manager.createNamedQuery("qrySearchEmployeeByLastName", Employee.class);
		qry.setParameter("lastName", lastName);
		return qry.getResultList();
	}//end of search employee on last name

	//search of employee on marital status
	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String maritalStatus)
			throws EmployeeException {
		TypedQuery<Employee> qry = manager.createNamedQuery("qrySearchEmployeeByMaritalStatus", Employee.class);
		qry.setParameter("maritalStatus", maritalStatus);
		return qry.getResultList();
	}//end of search employee on marital status
	
	//Start of search employee on department
	/*@Override
	public List<Employee> deptName(String deptName) {
		try {
			Department dept=this.getDeptId(deptName);
			System.out.println(dept);
	int id=		dept.getDeptId();
			System.out.println(id);
	Query qry= manager.createNamedQuery("empOnDeptName", Employee.class);
	qry.setParameter("id", id);
	
	return qry.getResultList();
			
			
			
		} catch (EmployeeException e) {
			System.out.println("problrm in daoIMPL deptName ");
		}
		
		return null;*/
	//}//End of search employee on department

	//Start of grade
	 	@SuppressWarnings("unchecked")
		@Override
			public List<Employee> SearchGrade(String grade) throws EmployeeException {
				
			Query qry=manager.createNamedQuery("qryGrade",Employee.class);
			qry.setParameter("grade",grade);
			List<Employee> qry1= qry.getResultList();
		
			return qry1;
			}
		  
		  @SuppressWarnings("unchecked")
		  @Override
		  public List<Grade> getData(String grade) throws EmployeeException
		  {
			  Query qry=manager.createNamedQuery("getGrade",Grade.class);
			  qry.setParameter("grade", grade);
				
				List<Grade> qry1= qry.getResultList();
				
				return qry1;
		  }//End of grade
		  
	//Start of login
	@Override
	public int isValid(String userName, String userPassword) {
		try { System.out.println("in dao isVakid");
		System.out.println(userName+userPassword);
		//String qry="select u from usermaster u where userName is :name";
		TypedQuery<UserMaster> result= manager.createNamedQuery("qry", UserMaster.class);
		result.setParameter("name", userName);
		UserMaster	user = (UserMaster) result.getSingleResult();
		
		System.out.println(user);
		
			if(user.getUserType().equals("admin"))
			{
				if(user.getUserPassword().equals(userPassword))
				{
					return 1;
				}//admin verified
			}
			
			else
			{
				if(user.getUserPassword().equals(userPassword))
				{
					return 2;
				}//employee verified
			}
		
	}	catch (Exception e1) {
		return 0;
	}
		
	return 0;
	}//End of login
	
	//Start of update data
	@Override
	public boolean updateEmp(Employee emp) throws EmployeeException {
		
		Employee empl=manager.merge(emp);
		manager.flush();
		return false;
	}

	@Override
	public Employee searchId(String Id) throws EmployeeException {
		Employee emp=manager.find(Employee.class, Id);
		return emp;
	}

	@Override
	public Department getDeptName(int deptId) throws EmployeeException {
		System.out.println(deptId);
		TypedQuery<Department> qry=manager.createNamedQuery("getDeptname", Department.class);
		qry.setParameter("deptId", deptId);
		Department dept=qry.getSingleResult();
		String deptname=dept.getDeptName();
		System.out.println(dept.getDeptName());
		return dept;
	}
	//End of update data
	
}
