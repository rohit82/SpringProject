package com.cg.empSystem.dto;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name="usermaster")
@Table(name="USER_MASTER")
@NamedQueries({ @NamedQuery(name = "qry" , query = "select u from usermaster u where userName is :name")
})
@SequenceGenerator(name="hibernate1_sequence",sequenceName="hibernate_sequence", allocationSize=5,initialValue=3000 )
public class UserMaster implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String userName;
	private String userPassword;
	private String userType;
	private Employee employeeUser;

	@Id
	@GenericGenerator(name = "hibernate1_sequence", strategy = "Mypackage.StringSequenceGenerator")
	@GeneratedValue(generator="hibernate1_sequence",strategy=GenerationType.SEQUENCE)
	@Column(name="USERID")
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	@Column(name="USERNAME")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Column(name="USERPASSWORD")
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	@Column(name="USERTYPE")
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/*@OneToOne(mappedBy="user",cascade=CascadeType.ALL)
	public Employee getEmployeeUser() {
		return employeeUser;
	}

	public void setEmployeeUser(Employee employeeUser) {
		this.employeeUser = employeeUser;
	}*/

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "UserMaster [userId=" + userId + ", userName=" + userName
				+ ", userPassword=" + userPassword + ", userType=" + userType
				+ "]";
	}
		
}
