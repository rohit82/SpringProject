package com.cg.ems.controller;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.inject.Model;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



import com.cg.ems.entities.Employee;
import com.cg.ems.service.IEmployeeService;


@Controller
public class EmployeeController 
{
    @Autowired
	private IEmployeeService employeeService;
    
    public EmployeeController() 
    {
		
	}

	public EmployeeController(IEmployeeService employeeService) 
	{
		super();
		this.employeeService = employeeService;
	}

	public IEmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}
    
	
	/************************************************************
	 * Providing Homepage to client
	 *************************************************************/
    
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String myLog( User user,HttpSession session)
	{
	
		
		return "login";
		
	}
	
	@RequestMapping("authenticate")
	public String myLogin(@RequestParam("userName")String name , @RequestParam("password")String pass,
			User user,HttpSession session) 
	{
		System.out.println("In controller");
		System.out.println("UserName:" +name +"pas" + pass );
		String retPage ;
		String role = employeeService.getRole(name,pass);
		System.out.println(role);
	
		if(role.equals("employee"))
		{
			//session.setAttribute("userId", user.getUserId());
			retPage = "employee";
			System.out.println(retPage);
		}
		
		
		else if(role.equals("admin"))
		{
			retPage = "admin";
			System.out.println(retPage);
		}
		else
		{
			retPage = "login"; 
		}
		
		return retPage;
	}
	
	/************************************************************
	 * Adding employee to the database
	 *************************************************************/
	@RequestMapping("addEmployee")
	public String getAddEmployeePage(Model model)
	{
		List<String> status=new ArrayList<>();
		status.add("Clothes");
		status.add("Married");
		status.add("Divorced");
		status.add("Seperated");
		status.add("Widowed");
		
		List<String> gender=new ArrayList<>();
		gender.add("Male");
		gender.add("Female");
		
		List<String> grade=new ArrayList<>();
		grade.add("M1");
		grade.add("M2");
		grade.add("M3");
		grade.add("M4");
		grade.add("M5");
		grade.add("M6");
		grade.add("M7");
		
	// Add the form backing bean to the binded to AddProduct.jsp Form
		model.addAttribute("employee", new Employee());
		
		// Add categories to dropdownlistin AddProduct dynamically
		model.addAttribute("status", status);
		model.addAttribute("gender", gender);
		model.addAttribute("grade", grade);
		
		//Return View
		return "AddEmployeePage";
		
	}
	
	@RequestMapping(value="addEmployeeDetails")
	public String employeeAdd(@ModelAttribute("data") Employee employee )
	{
		
		employeeService.addEmployeeDetails(employee);
			
		return "added";
	}
	
	
	/************************************************************
	 * Searching employee based on employee id
	 *************************************************************/
	
	@RequestMapping("searchEmployeeOnId")
	public String getSearchEmployeeById(Model model)
	{
		
		return "GetEmployeeIDPage";
	}
	
	@RequestMapping("processSearchEmployeeById")
	public ModelAndView processSearchEmployeeById(@RequestParam("empId") String empId)
	{
		Employee employee=null;
		
		try 
		{
			employee=employeeService.searchEmployeeById(empId);
			return new ModelAndView("GetEmployeeIDPage","employee",employee);
		} 
		catch (Exception e) 
		{
			
			return new ModelAndView("ErrorPage","errmsg","Could not get employee. Reason :"+e.getMessage());
		}
		
	
	}
	
	/************************************************************
	 * Searching employee based on employee Marital Status
	 *************************************************************/
	
	@RequestMapping("searchEmployeeOnMaritalStatus")
	public String getSearchEmployeeByMaritalStatus(Model model)
	{
		
		return "GetEmployeeMaritalStatusPage";
	}
	
	@RequestMapping("processsearchEmployeeOnMaritalStatus")
	public ModelAndView processSearchEmployeeByMaritalStatus(@RequestParam("empMaritalStatus") String empMaritalStatus)
	{
		List<Employee> employees=null;
		
		try 
		{
			employees=employeeService.searchEmployeeByMaritalStatus(empMaritalStatus);
					
			return new ModelAndView("GetEmployeeMaritalStatusPage","employees",employees);
		} 
		catch (Exception e) 
		{
			
			return new ModelAndView("ErrorPage","errmsg","Could not get employee. Reason :"+e.getMessage());
		}
		
	
	}
	
}
