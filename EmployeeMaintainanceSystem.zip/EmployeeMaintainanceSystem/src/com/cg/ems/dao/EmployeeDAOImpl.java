package com.cg.ems.dao;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;






import com.cg.ems.entities.Employee;
import com.cg.ems.entities.Grade;
import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;

@Repository("employeeDAO")
public class EmployeeDAOImpl implements IEmployeeDAO
{
	@PersistenceContext
	private EntityManager entityManager;

	public EmployeeDAOImpl() 
	{
		super();
	}

	 /********************************************************************
     * Add New Employee
     *******************************************************************/
	
	@Override
	public void addEmployeeDetails(Employee emp) throws EmployeeException 
	{
	
		try 
		{
			entityManager.persist(emp);
	     
		} 
		catch (Exception e) 
		{
			
			throw new EmployeeException(e.getMessage());
		}
		
	}
	
	
	

	@Override
	public int addLoginDetails(User user) throws EmployeeException 
	{
		
		return 0;
	}

	@Override
	public List<Employee> showAllEmployees() throws EmployeeException,
			SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException 
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
    /********************************************************************
     * Search employee based on employee id
     *******************************************************************/

	@Override
	public Employee searchEmployeeById(String EmpId) throws EmployeeException 
	{
		Employee employee=null;
		
		try 
		{
			employee=entityManager.find(Employee.class, EmpId);
		} 
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());
		}
		
		if(employee==null)
		{
			throw new EmployeeException("No employee found with the id"+EmpId);
		}
		return employee;
	}
	

	 /********************************************************************
     * Search employee based on employee first name
     *******************************************************************/
	@Override
	public List<Employee> searchEmployeeByFirstName(String firstName)
			throws EmployeeException 
	{
		
		return null;
	}
	

	 /********************************************************************
     * Search employee based on employee last name
     *******************************************************************/
	
	@Override
	public List<Employee> searchEmployeeByLastName(String lastName)
			throws EmployeeException 
	{
		
		return null;
	}
	

	 /********************************************************************
     * Search employee based on employee department
     *******************************************************************/
	
	
	@Override
	public List<Employee> searchEmployeeByDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException 
			
	{
        List<Employee> employees=null;
		
		try 
		{
			
			Query query=entityManager.createQuery("select e,d from Employee e,Department d where e.Dept_ID=d.Dept_ID");
			query.getResultList();
			
			
		} 
		catch (Exception e) 
		{
			
			throw new EmployeeException(e.getMessage());
		}
		
		return employees;
	}
	
	
	 /********************************************************************
     * Search employee based on employee grade
     *******************************************************************/

	@Override
	public List<Employee> searchEmployeeByGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException 
	{
		
		List<Employee> employees=null;
		
		try 
		{
			
			Query query=entityManager.createQuery("select e,g from Employee e,Grade_Master g where e.Grade_Code=g.Grade_Code");
			query.getResultList();
			
		
		
			
		} 
		catch (Exception e) 
		{
			
			throw new EmployeeException(e.getMessage());
		}
		
		return employees;
	}
	
	
	 /********************************************************************
     * Search employee based on employee marital status
     *******************************************************************/

	@Override
	public List<Employee> searchEmployeeByMaritalStatus(String status)throws EmployeeException
			
	{
        List<Employee> employees=null;
		
		try 
		{
			
			TypedQuery<Employee> tQuery=entityManager.createQuery("select e from Employee e where Emp_Marital_Status=?",Employee.class);
			tQuery.getResultList();
				
		} 
		catch (Exception e) 
		{
			
			throw new EmployeeException(e.getMessage());
		}
		
		return employees;
		
		
	}
	
	
	 /********************************************************************
     * Update employee details
     *******************************************************************/
	@Override
	public void updateEmployeeDetails(Employee emp) throws EmployeeException 
	{
		
		
	}

	
	
	

}
