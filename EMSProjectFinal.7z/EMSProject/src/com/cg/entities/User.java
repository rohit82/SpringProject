package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="User_Master")
public class User {
	
	@Id
	@NotEmpty(message="User Id cannot be empty")
	@Column(name="UserId", nullable=false)
	private String UserId;
	
	
	@NotEmpty(message="User Name cannot be empty")
	@Column(name="UserName" , nullable=false)
	private String UserName;
	
	@NotEmpty(message="User Password cannot be empty")
	@Column(name="UserPassword" ,nullable=false)
	private String UserPassword;
	
	@NotEmpty(message="UserType cannot be empty")
	@Column(name="UserType" , nullable=false)
	private String UserType;
	
	public User() {
		super();
	}
	
	public User(String userId, String userName, String userPassword,
			String userType) {
		super();
		UserId = userId;
		UserName = userName;
		UserPassword = userPassword;
		UserType = userType;
	}

	public String getUserId() {
		return UserId;
	}

	public void setUserId(String userId) {
		UserId = userId;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public String getUserType() {
		return UserType;
	}

	public void setUserType(String userType) {
		UserType = userType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((UserId == null) ? 0 : UserId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (UserId == null) {
			if (other.UserId != null)
				return false;
		} else if (!UserId.equals(other.UserId))
			return false;
		return true;
	}
	
	
	

}
