package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Employee;
import com.cg.entities.User;
import com.cg.exception.EmployeeException;



@Repository
public class EmployeeDaoImpl implements EmployeeDao
{
	
	@PersistenceContext
	private EntityManager entityManager;
	

	public EmployeeDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EmployeeDaoImpl() {
		super();
	}
	
	//------------------------------------------------------------------

	@Override
	public void addEmployeeDetails(Employee emp) throws EmployeeException {
			
		try 
		{
			
			entityManager.persist(emp);
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			
		}
		
		
	}

	@Override
	public void addLoginDetails(User user) throws EmployeeException {
		try 
		{
			
			entityManager.persist(user);
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			
		}
		
	}

	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
	
		List<Employee> eList = new ArrayList<Employee>();
		try
		{
			
			eList = entityManager.createQuery("select e from Employee e").getResultList();
		
		}
		catch(Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		
		return eList ;
	}
	

	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		
		return 0;
	}

	@Override
	public Employee searchEmployeeOnId(String EmpId) throws EmployeeException {
		Query query = entityManager.createQuery("FROM Employee WHERE empId=:EMP_ID");
		query.setParameter("EMP_ID", EmpId);
		Employee eList =(Employee)query.getSingleResult();
			return eList;
	}

	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)
			throws EmployeeException 
			{
	Query query = entityManager.createQuery("FROM Employee WHERE empFname=:Emp_First_Name");
	query.setParameter("Emp_First_Name", firstName);
	List <Employee> elist = query.getResultList();
	return elist;
	}

	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)
			throws EmployeeException {
		
		Query query = entityManager.createQuery("FROM Employee WHERE empLname=:Emp_Last_Name");
		query.setParameter("Emp_Last_Name", lastName);
		List <Employee> elist = query.getResultList();
		return elist;
	}

	@Override
	public List<Employee> searchEmployeeOnDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException {

		return null;
	}

	@Override
	public List<Employee> searchEmployeeOnGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException {
	
		return null;
	}

	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String status1,
			String status2, String status3, String status4, String status5)
			throws EmployeeException {
		
		return null;
	}

	@Override
	public void updateEmployee(Employee emp) throws EmployeeException {
	
	}

	@Override
	public String getRole(String userName, String userPassword)
			throws EmployeeException {
		User usr = null;
		try 
		{
			System.out.println(userName + " " + userPassword);
			String query = "Select u from User u where u.UserName=:UserName AND u.UserPassword=:UserPassword ";
			TypedQuery<User> queryOne = entityManager.createQuery(query, User.class);
			queryOne.setParameter("UserName", userName);
			queryOne.setParameter("UserPassword", userPassword);
			
			usr = queryOne.getSingleResult();
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			
		}
		

		return usr.getUserType();
	}


	

	
}
